# Ada's Relish — storefront site

A static, build-free site (plain HTML + one compiled JS file) — no npm install needed to deploy.

## Deploy to Netlify

**Option A — drag & drop (fastest)**
1. Go to https://app.netlify.com/drop
2. Drag this whole folder (or the unzipped contents) onto the page.
3. Netlify gives you a live URL immediately. Rename the site under Site settings → Change site name for a nicer subdomain (e.g. `adasrelish.netlify.app`).

**Option B — Netlify CLI**
```
npm install -g netlify-cli
cd this-folder
netlify deploy --prod
```

**Option C — GitHub**
Push this folder to a repo, then in Netlify: "Add new site" → "Import an existing project" → pick the repo. Build command: leave blank. Publish directory: `.`

## What's inside
- `index.html` — the page shell, loads fonts + React from CDN, then `app.js`
- `app.js` — the whole site (Home, Menu, Gallery, About, Cart, Contact), compiled from JSX to plain JS so no build step runs on Netlify
- `src/app.src.jsx` — the original JSX source, kept for future edits
- `netlify.toml` — routing config (safe default, this site doesn't use client-side routing paths)

## Editing later
If you want to change menu items, prices, copy, or the WhatsApp number:
1. Edit `src/app.src.jsx`
2. Recompile with Babel: `npx babel src/app.src.jsx --out-file app.js` (requires `npm install @babel/core @babel/cli @babel/preset-react` once)
3. Re-deploy

The WhatsApp order number lives near the top of `app.src.jsx` as `WHATSAPP_NUMBER`.

## Known placeholder
All dish photos and Ada's portrait are styled placeholder "plates" in her brand colors — swap in real photography by replacing the `PlatePlaceholder` component and hero image block in `app.src.jsx` with `<img>` tags pointing at real image files (add an `/images` folder alongside `index.html`).
